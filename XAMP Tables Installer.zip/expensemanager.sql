-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2015 at 08:05 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `expensemanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `contact` varchar(15) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `type` int(5) NOT NULL DEFAULT '2',
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`contact`, `state`, `city`, `country`, `type`, `username`) VALUES
('08322604275', 'UP', 'Pernem', 'India', 2, 'ja@yahoo.com'),
('083226042751', 'Goa', 'Boma', 'India', 2, 'ja@yahoo.com'),
('17532323369', 'Goa', 'Pernem', 'India', 1, 'rd@gmail.com'),
('23454235341', 'Goa', 'Santa Cruz', 'India', 2, 'ja@yahoo.com'),
('3453453422', 'Goa', 'Panjim', 'India', 2, 'ja@yahoo.com'),
('38469345', 'Goa', 'Ponda', 'India', 1, 'ja@yahoo.com'),
('393635241', 'Goa', 'Ambaulim', 'India', 2, 'ja@yahoo.com'),
('481178117887', 'Maruia', 'State Highway', 'New Zealand', 2, 'ja@yahoo.com'),
('7878454124', 'Goa', 'Cuncolim', 'India', 2, 'ja@yahoo.com'),
('7897897856', 'Goa', 'Siolim', 'India', 2, 'ja@yahoo.com'),
('9198289298292', 'Goa', 'Colvale', 'India', 2, 'ja@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `budget`
--

CREATE TABLE IF NOT EXISTS `budget` (
`bugid` int(11) NOT NULL,
  `bdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `maxbudget` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `budget`
--

INSERT INTO `budget` (`bugid`, `bdate`, `maxbudget`) VALUES
(1, '2015-04-25 17:06:03', 233),
(2, '2015-04-29 17:06:33', 566),
(3, '2015-04-26 18:30:00', 6789),
(4, '2015-04-25 17:19:01', 0),
(5, '2015-04-25 17:19:04', 0),
(6, '2015-04-25 17:26:15', 477),
(7, '2015-04-25 18:05:57', 0),
(8, '2015-05-02 18:30:00', 9000),
(9, '2015-06-08 18:30:00', 2345),
(10, '2015-06-08 18:30:00', 2345),
(11, '2015-06-08 18:30:00', 2345),
(12, '2015-06-08 18:30:00', 2345),
(13, '2015-06-08 18:30:00', 2345),
(14, '2015-06-08 18:30:00', 2345),
(16, '2015-04-25 20:26:43', 0),
(17, '2015-05-13 18:30:00', 35345),
(18, '2015-05-13 18:30:00', 35345),
(19, '0000-00-00 00:00:00', 12345),
(20, '2015-05-11 18:30:00', 9999),
(21, '2015-06-18 18:30:00', 4567),
(22, '2015-06-26 18:30:00', 7542),
(23, '2015-05-20 18:30:00', 9400),
(24, '2015-08-14 18:30:00', 78555),
(25, '2015-08-14 18:30:00', 122222),
(26, '2015-04-26 04:57:31', 0),
(27, '2015-04-26 04:58:35', 0),
(28, '2015-04-26 05:32:12', 0),
(29, '2015-04-26 05:32:54', 0),
(30, '2015-04-26 05:33:51', 0),
(31, '2015-04-26 06:13:05', 0),
(32, '2015-04-26 06:13:40', 0),
(33, '2015-04-26 06:14:07', 0),
(34, '2015-04-26 06:35:49', 0),
(35, '2015-04-26 07:15:42', 0),
(37, '2015-04-26 07:46:55', 0),
(38, '2015-04-26 07:47:59', 0),
(39, '2015-04-26 07:48:47', 0),
(40, '2015-09-30 18:30:00', 1700);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `location` varchar(50) NOT NULL,
  `family_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `customertype` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`firstname`, `lastname`, `username`, `dob`, `location`, `family_name`, `password`, `country`, `state`, `customertype`) VALUES
('trt', 'ad', '3@k.com', '2015-04-16', 'Colvale', 'sdasd', 'rahulx11x', 'India', 'Goa', 1),
('aasdasd', 'adsaads', 'a3@1.com', '2015-04-22', 'Pernem', 'bambo', 'toy', 'India', 'Goa', 1),
('dasd1', 'stsfd1', 'a@1.com', '2015-05-15', 'Colvale1', 'bambo', 'a2', 'Indiaf', 'Goag', 1),
('asda', 'ads', 'aads4@asdo.com', '2015-04-02', 'Assagao', 'bambo1', 'toy', 'India', 'Goa', 1),
('adasd', 'dasd', 'adadasd', '2015-04-07', 'Sanquelim', 'dias101', '234234', 'India', 'Goa', 2),
('dasasd', 'dadasdasd', 'adadasdasd', '2015-04-13', 'Savarjuva', 'dias101', '34224', 'India', 'Maharashtra', 2),
('adads', 'ads', 'ads@sdf.com', '2015-04-15', 'Menkurem', 'bambo', 'toy', 'India', 'Goa', 1),
('dadad', 'adsadasda', 'asda@adsa.com', '2015-04-14', 'Taleigao', 'dias101100', '454', 'India', 'Goa', 2),
('asdadsdsaasd', 'ddsadas', 'ddd@rrr.com', '2015-04-08', 'Pomburpa', 'gggt', 'rahulx11x', 'India', 'Goa', 1),
('Lorraiine', 'Dcosta', 'fdg@ds.com', '2015-05-28', 'Bainguinim', 'dcostas_13', '123', 'India', 'Goa', 2),
('asdasdd', 'asdasd', 'rahul123@gmail.com', '2015-04-14', 'Palyem', 'dias101100', 'dasdasd', 'India', 'Goa', 2),
('Rahul', 'Dcosta', 'rahul4@gmail.com', '1990-04-14', 'Casne-Amberem-Poroscadem VP', 'khan', '234', 'India', 'Goa', 1),
('Rahul', 'Dcosta', 'rahuldc999@gmail.com', '1990-11-16', 'Raia', 'dcostas_13', 'rahulx11x', 'India', 'Goa', 1),
('dhdftdfgdf', 'dfgdfgdtd', 'rahulwe@gmail.com', '2015-04-21', 'Maem', 'dias101', 'dgdfg', 'India', 'Goa', 2),
('ada', 'sada', 're@r.com', '2015-04-22', 'Padlos', 'bambo', 'toy', 'India', 'Maharashtra', 1),
('Rohan ', 'Dcosta', 'ron@gmail.com', '2015-04-15', 'Ponda', 'dcostas_13', '123', 'India', 'Goa', 2),
('rohit', 'roy', 'roy@gmail.com', '2015-04-13', 'Bambolim', 'khan', '12345roy', 'India', 'Goa', 2),
('asdas', 'da', 'rt@gmail.com', '2015-04-15', 'Mapusa', 'sdasddas', 'dssad', 'India', 'Goa', 1),
('gdfgdfg', 'dgdfgdf', 'te@gi.com', '2015-04-17', 'Zoruzalem Village Road', 'dias101100', '343443', 'India', 'Goa', 2),
('coy', 'toy', 'toy@g.com', '1942-04-15', 'Ponda', 'Toyser', 'toy', 'India', 'Goa', 1);

-- --------------------------------------------------------

--
-- Table structure for table `datesubtable`
--

CREATE TABLE IF NOT EXISTS `datesubtable` (
`d_id` int(11) NOT NULL,
  `tag` varchar(200) NOT NULL,
  `c_username` varchar(200) NOT NULL,
  `start_date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datesubtable`
--

INSERT INTO `datesubtable` (`d_id`, `tag`, `c_username`, `start_date`) VALUES
(141, 'Milk power', 'rahuldc999@gmail.com', '2015-04-25'),
(142, 'asdasd', 'rahuldc999@gmail.com', '2015-04-24'),
(143, 'Shoes', 'rahuldc999@gmail.com', '2015-04-25'),
(144, 'Rocksolid', 'rahuldc999@gmail.com', '2015-04-25'),
(145, 'Rocksolid', 'rahuldc999@gmail.com', '2015-04-26'),
(147, 'Food', 'rahuldc999@gmail.com', '2015-04-26'),
(152, 'uoop', 'rahuldc999@gmail.com', '2015-04-15'),
(153, 'uoop', 'rahuldc999@gmail.com', '2015-04-16'),
(154, 'uoop', 'rahuldc999@gmail.com', '2015-04-17'),
(155, 'uoop', 'rahuldc999@gmail.com', '2015-04-18'),
(156, 'soop', 'toy@g.com', '2015-04-26'),
(157, 'asdasd', 'rahuldc999@gmail.com', '2015-04-25'),
(159, 'Milk power', 'rahuldc999@gmail.com', '2015-04-26'),
(161, 'sdfop', 'rahuldc999@gmail.com', '2015-05-08'),
(162, 'sdf', 'rahuldc999@gmail.com', '2015-05-09'),
(163, 'sdf', 'rahuldc999@gmail.com', '2015-05-10'),
(164, 'sdfop', 'rahuldc999@gmail.com', '2015-05-09'),
(165, 'sdfop', 'rahuldc999@gmail.com', '2015-05-09'),
(166, 'adad', 'rahuldc999@gmail.com', '2015-05-11'),
(181, 'motrrr', 'rahuldc999@gmail.com', '2015-05-08'),
(182, 'motrrr', 'rahuldc999@gmail.com', '2015-05-11'),
(183, 'motrrr', 'rahuldc999@gmail.com', '2015-05-12'),
(184, 'rebook', 'rahuldc999@gmail.com', '2015-08-14'),
(185, 'Books', 'rahuldc999@gmail.com', '2015-04-29'),
(186, 'stocks', 'ron@gmail.com', '2015-04-29'),
(187, 'goop', 'ron@gmail.com', '2015-04-29'),
(188, 'dasdadadjadadajkldajlkdadladjaldjlkaldjkdas', 'ron@gmail.com', '2015-05-01'),
(189, 'adssssssssssssssssssss', 'rahuldc999@gmail.com', '2015-05-01'),
(190, 'rtyy', 'ron@gmail.com', '2015-05-01'),
(191, 'asdadadad123', 'rahuldc999@gmail.com', '2015-05-01'),
(192, 'roooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo', 'rahuldc999@gmail.com', '2015-04-21'),
(193, 'polish', 'rahuldc999@gmail.com', '2015-05-01'),
(194, 'polish', 'rahuldc999@gmail.com', '2015-05-02'),
(195, 'asdasd', 'rahuldc999@gmail.com', '2015-05-02'),
(196, 'asdasd', 'rahuldc999@gmail.com', '2015-05-03'),
(197, 'asdasd', 'rahuldc999@gmail.com', '2015-05-04'),
(198, 'asdasd', 'rahuldc999@gmail.com', '2015-05-05'),
(199, 'cosmetics', 'fdg@ds.com', '2015-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE IF NOT EXISTS `expenses` (
`exp_id` int(11) NOT NULL,
  `date_id` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL DEFAULT '0',
  `description` varchar(500) DEFAULT NULL,
  `end_date` date NOT NULL,
  `rstatus` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`exp_id`, `date_id`, `price`, `description`, `end_date`, `rstatus`) VALUES
(124, 141, '2131', 'asdasd ', '2015-04-25', 1),
(125, 142, '99', ' ', '2015-04-24', 0),
(126, 143, '345', '', '2015-04-25', 1),
(127, 144, '34', 'asda', '2015-04-25', 0),
(128, 145, '34', 'asda ', '2015-04-26', 1),
(130, 147, '123', '', '2015-04-26', 0),
(135, 152, '784', 'hjkhk', '2015-04-15', 0),
(136, 153, '784', 'hjkhk', '2015-04-16', 1),
(137, 154, '784', 'hjkhk', '2015-04-17', 1),
(138, 155, '784', 'hjkhk', '2015-04-18', 1),
(139, 156, '45', '', '2015-04-26', 0),
(142, 161, '78', '   ', '2015-05-08', 0),
(143, 162, '78', '', '2015-05-09', 1),
(144, 163, '78', '', '2015-05-10', 1),
(159, 181, '452', '', '2015-05-08', 0),
(160, 182, '452', '', '2015-05-11', 1),
(161, 183, '452', '', '2015-05-12', 1),
(162, 184, '781', '', '2015-08-14', 0),
(163, 185, '29', 'adasdasd ', '2015-04-29', 0),
(164, 186, '44', 'asdasd', '2015-04-29', 0),
(165, 187, '21', '', '2015-04-29', 0),
(166, 188, '34', '', '2015-05-01', 0),
(167, 189, '12', ' ', '2015-05-01', 0),
(168, 190, '3', '', '2015-05-01', 0),
(169, 191, '32', ' dasddd', '2015-05-01', 0),
(170, 192, '45', '', '2015-04-21', 0),
(171, 193, '345', 'dfgdfgdfgdfgdfg', '2015-05-01', 0),
(172, 194, '345', 'dfgdfgdfgdfgdfg', '2015-05-02', 1),
(173, 195, '23', '', '2015-05-02', 0),
(174, 196, '23', '', '2015-05-03', 1),
(175, 197, '23', '', '2015-05-04', 1),
(176, 198, '23', '', '2015-05-05', 1),
(177, 199, '411', '', '2015-05-03', 0);

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE IF NOT EXISTS `family` (
  `family_name` varchar(50) NOT NULL,
  `bgid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`family_name`, `bgid`) VALUES
('rockstart', 1),
('khan', 2),
('dcostas_13', 3),
('dias101', 4),
('dias101100', 5),
('khan', 6),
('bambo', 7),
('Toyser', 16),
('dcostas_13', 22),
('dcostas_13', 23),
('dcostas_13', 25),
('vikings', 26),
('asd', 27),
('sdasd', 28),
('sdasddas', 29),
('sdasddas', 30),
('sdda', 31),
('sdda', 32),
('sdads', 33),
('gggt', 34),
('poiled', 35),
('bambo', 37),
('bambo', 38),
('bambo1', 39),
('dcostas_13', 40);

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE IF NOT EXISTS `offer` (
`offerid` int(11) NOT NULL,
  `startdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tag` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `branchno` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`offerid`, `startdate`, `enddate`, `tag`, `description`, `branchno`) VALUES
(2, '2015-05-01 18:30:00', '2015-05-01 18:30:00', 'Bikes', 'asdasd ', '08322604275'),
(4, '2015-05-01 18:30:00', '2015-05-04 18:30:00', 'poyato12', 'dsa adsasdads  ', '08322604275'),
(5, '2015-05-02 18:30:00', '2015-05-01 20:25:40', 'shoes', 'fgfgfgfg', '08322604275'),
(6, '2015-05-02 04:27:07', '2015-05-02 04:27:07', 'shoes', 'ggghfhfh', '08322604275'),
(18, '2015-04-30 18:30:00', '2015-04-30 18:30:00', 'towels', 'ghjhjghj', '38469345'),
(19, '2015-05-01 18:30:00', '2015-05-01 18:30:00', 'towels', 'ghjhjghj', '38469345'),
(20, '2015-05-02 18:30:00', '2015-05-02 18:30:00', 'towels', 'ghjhjghj', '38469345'),
(21, '2015-05-03 18:30:00', '2015-05-03 18:30:00', 'towels', 'ghjhjghj', '38469345'),
(22, '2015-05-04 18:30:00', '2015-05-04 18:30:00', 'towels', 'ghjhjghj', '38469345'),
(23, '2015-05-02 18:30:00', '2015-05-02 18:30:00', 'poyato12', 'dsa adsasdads  ', '9198289298292'),
(24, '2015-05-03 18:30:00', '2015-05-03 18:30:00', 'poyato12', 'dsa adsasdads  ', '08322604275'),
(25, '2015-05-04 18:30:00', '2015-05-04 18:30:00', 'poyato12', 'dsa adsasdads  ', '08322604275'),
(34, '2015-05-01 18:30:00', '2015-05-01 18:30:00', 'dfjhsdfhsdklfhsdlkfhsdlkfhsfkjlsfjlksdfsdfsdfsdfsd', 'fsdf', '08322604275'),
(35, '2015-05-02 19:16:00', '2015-05-02 19:16:00', 'shoes', 'dasdasdasdadasd', '17532323369'),
(36, '2015-05-02 18:30:00', '2015-05-02 18:30:00', 'Rebook', 'fghfhvbnvbnvnvnvnvnvnvnvnvbnvnvnvbn', '23454235341'),
(37, '2015-05-02 18:30:00', '2015-05-02 18:30:00', 'bedshits', 'dadasdas', '481178117887');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE IF NOT EXISTS `vendor` (
  `username` varchar(50) NOT NULL,
  `vendorname` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`username`, `vendorname`, `password`, `date`) VALUES
('ja@yahoo.com', 'Jstores', '123', '2015-04-10'),
('jatinsharma698@gmail.com', 'jatin Sharma', '0123654789', '1993-08-01'),
('l@rr.com', 'ccccc', '1', '2015-04-05'),
('po@jikl.com', 'jjjjaaa', 'poiuyl', '2015-04-18'),
('rd@gmail.com', 'R traders', '74120.36', '1990-11-16'),
('u@yu.com', 'nbnvnvnb', '41', '2015-04-25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
 ADD PRIMARY KEY (`contact`), ADD KEY `username` (`username`);

--
-- Indexes for table `budget`
--
ALTER TABLE `budget`
 ADD PRIMARY KEY (`bugid`), ADD KEY `bugid` (`bugid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`username`), ADD KEY `family_name` (`family_name`);

--
-- Indexes for table `datesubtable`
--
ALTER TABLE `datesubtable`
 ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
 ADD PRIMARY KEY (`exp_id`), ADD KEY `date_id` (`date_id`);

--
-- Indexes for table `family`
--
ALTER TABLE `family`
 ADD PRIMARY KEY (`family_name`,`bgid`), ADD KEY `bgid` (`bgid`), ADD KEY `bgid_2` (`bgid`);

--
-- Indexes for table `offer`
--
ALTER TABLE `offer`
 ADD PRIMARY KEY (`offerid`), ADD KEY `brancid` (`branchno`), ADD KEY `brancno` (`branchno`), ADD KEY `brancno_2` (`branchno`), ADD KEY `brancno_3` (`branchno`), ADD KEY `branchno` (`branchno`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
 ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `budget`
--
ALTER TABLE `budget`
MODIFY `bugid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `datesubtable`
--
ALTER TABLE `datesubtable`
MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=200;
--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
MODIFY `exp_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=178;
--
-- AUTO_INCREMENT for table `offer`
--
ALTER TABLE `offer`
MODIFY `offerid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `branch`
--
ALTER TABLE `branch`
ADD CONSTRAINT `jop` FOREIGN KEY (`username`) REFERENCES `vendor` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
ADD CONSTRAINT `kio` FOREIGN KEY (`date_id`) REFERENCES `datesubtable` (`d_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `family`
--
ALTER TABLE `family`
ADD CONSTRAINT `bkilkl` FOREIGN KEY (`bgid`) REFERENCES `budget` (`bugid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `offer`
--
ALTER TABLE `offer`
ADD CONSTRAINT `dasd` FOREIGN KEY (`branchno`) REFERENCES `branch` (`contact`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
